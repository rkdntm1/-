package www.dream.com.delivery.model;

public class DeliveryResult {

}
