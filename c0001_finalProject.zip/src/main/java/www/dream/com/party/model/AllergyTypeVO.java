package www.dream.com.party.model;

import lombok.Data;
/**
 * 알러지정보
 * @author qoddn987
 *
 */
@Data
public class AllergyTypeVO {
	private String contactAllergyType;	
	private String allergyType;		
}
