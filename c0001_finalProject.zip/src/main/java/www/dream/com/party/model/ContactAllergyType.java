package www.dream.com.party.model;

import lombok.Data;

@Data
public class ContactAllergyType {
	private String contactAllergyType;	
	private String allergyTypesInfo;		
}
