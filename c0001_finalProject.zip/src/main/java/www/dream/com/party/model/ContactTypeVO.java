package www.dream.com.party.model;

import lombok.Data;

@Data
public class ContactTypeVO {
	private String contactPointType;	
	private String description;			
}
