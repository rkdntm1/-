package www.dream.com.hashTag.model;

public interface IHashTagOpponent {
	public String getId();
	public String getType();
}
