package www.dream.com.common.persistence;

public interface CommonMngVOMapper {

}
