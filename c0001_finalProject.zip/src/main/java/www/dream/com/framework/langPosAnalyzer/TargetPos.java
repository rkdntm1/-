package www.dream.com.framework.langPosAnalyzer;

public enum TargetPos {
	//일반명사, 고유명사, 영단어, 한자
	NNG, NNP, SL, SH;
}
